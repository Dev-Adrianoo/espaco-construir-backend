package br.com.espacoconstruir.tutoring_backend.model;

public enum ScheduleModality {
  ONLINE,
  IN_PERSON,
  HYBRID
}