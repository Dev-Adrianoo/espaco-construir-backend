package br.com.espacoconstruir.tutoring_backend.model;

public enum Role {
    PROFESSORA,
    RESPONSAVEL,
    ALUNO
}
