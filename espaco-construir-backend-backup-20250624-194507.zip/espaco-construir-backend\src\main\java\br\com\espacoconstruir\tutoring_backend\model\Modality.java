package br.com.espacoconstruir.tutoring_backend.model;

public enum Modality {
    PRESENTIAL,
    ONLINE
}
