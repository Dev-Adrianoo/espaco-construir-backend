package br.com.espacoconstruir.tutoring_backend.dto;

import lombok.Data;

@Data
public class TokenRequestDTO {
    private String token;
} 