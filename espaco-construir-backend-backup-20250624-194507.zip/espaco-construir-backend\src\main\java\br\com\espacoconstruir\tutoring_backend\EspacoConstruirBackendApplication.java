package br.com.espacoconstruir.tutoring_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EspacoConstruirBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EspacoConstruirBackendApplication.class, args);
	}

}
