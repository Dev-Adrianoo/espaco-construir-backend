package br.com.espacoconstruir.tutoring_backend.model;

public enum ScheduleStatus {
  SCHEDULED,
  IN_PROGRESS,
  COMPLETED,
  CANCELLED
}