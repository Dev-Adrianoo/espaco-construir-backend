package br.com.espacoconstruir.tutoring_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EspacoConstruirBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
